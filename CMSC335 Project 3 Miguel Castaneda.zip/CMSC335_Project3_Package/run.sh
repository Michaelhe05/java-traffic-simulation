#!/usr/bin/env bash
set -euo pipefail
./compile.sh
java -cp build TrafficSimulationApp
