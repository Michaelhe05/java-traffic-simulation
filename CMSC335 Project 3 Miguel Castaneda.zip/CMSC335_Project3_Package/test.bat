@echo off
call compile.bat
if errorlevel 1 exit /b 1
java -ea -cp build TrafficSimulationTests
