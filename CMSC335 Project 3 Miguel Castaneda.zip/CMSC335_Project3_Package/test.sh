#!/usr/bin/env bash
set -euo pipefail
./compile.sh
java -ea -cp build TrafficSimulationTests
