CMSC 335 Project 3 - Concurrent Traffic Simulation
Author: Miguel Castaneda
Date: July 3, 2026

QUICK START
Windows:
  1. Open Command Prompt in this folder.
  2. Run: compile.bat
  3. Run: run.bat

macOS/Linux:
  1. Open a terminal in this folder.
  2. Run: chmod +x compile.sh run.sh test.sh
  3. Run: ./run.sh

AUTOMATED TESTS
Windows: test.bat
macOS/Linux: ./test.sh

MANUAL COMMANDS
  javac -Xlint:all -d build src/*.java
  java -cp build TrafficSimulationApp
  java -ea -cp build TrafficSimulationTests

CONFIGURATION
Edit config/simulation.properties before launching to change cycle times, update rate,
maximum counts, and the required 1000-meter intersection spacing.

The full developer/user guide, UML diagram, assumptions, limitations, test plan,
screenshots, and lessons learned are in documentation/CMSC335_Project3_Documentation.docx.
