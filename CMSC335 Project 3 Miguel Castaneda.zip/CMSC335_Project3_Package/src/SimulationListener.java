/*
 * File: SimulationListener.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Defines callbacks from simulation worker threads to the GUI.
 */

import java.time.LocalDateTime;

/** Receives thread-safe notifications from the simulation controller. */
public interface SimulationListener {
    void onClockTick(LocalDateTime timestamp, String threadName);

    void onIntersectionUpdated(Intersection intersection);

    void onCarUpdated(SimulatedCar car);

    void onStatusChanged(SimulationStatus status);

    void onLogMessage(String message);
}
