/*
 * File: SimulationConfig.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Loads validated simulation settings from simulation.properties.
 */

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Immutable validated application configuration. */
public final class SimulationConfig {
    private static final int DEFAULT_INTERSECTIONS = 3;
    private static final int DEFAULT_CARS = 3;
    private static final int DEFAULT_SPACING_METERS = 1000;
    private static final int DEFAULT_GREEN_SECONDS = 5;
    private static final int DEFAULT_YELLOW_SECONDS = 2;
    private static final int DEFAULT_RED_SECONDS = 5;
    private static final int DEFAULT_CAR_UPDATE_MILLISECONDS = 100;
    private static final int DEFAULT_MAX_CARS = 12;
    private static final int DEFAULT_MAX_INTERSECTIONS = 10;

    private final int defaultIntersections;
    private final int defaultCars;
    private final int intersectionSpacingMeters;
    private final int greenSeconds;
    private final int yellowSeconds;
    private final int redSeconds;
    private final int carUpdateMilliseconds;
    private final int maxCars;
    private final int maxIntersections;

    private SimulationConfig(Properties properties) {
        defaultIntersections = positiveInt(properties, "default.intersections", DEFAULT_INTERSECTIONS);
        defaultCars = positiveInt(properties, "default.cars", DEFAULT_CARS);
        intersectionSpacingMeters = positiveInt(properties, "intersection.spacing.meters", DEFAULT_SPACING_METERS);
        greenSeconds = positiveInt(properties, "light.green.seconds", DEFAULT_GREEN_SECONDS);
        yellowSeconds = positiveInt(properties, "light.yellow.seconds", DEFAULT_YELLOW_SECONDS);
        redSeconds = positiveInt(properties, "light.red.seconds", DEFAULT_RED_SECONDS);
        carUpdateMilliseconds = positiveInt(
                properties,
                "car.update.milliseconds",
                DEFAULT_CAR_UPDATE_MILLISECONDS);
        maxCars = positiveInt(properties, "maximum.cars", DEFAULT_MAX_CARS);
        maxIntersections = positiveInt(
                properties,
                "maximum.intersections",
                DEFAULT_MAX_INTERSECTIONS);

        if (defaultCars > maxCars) {
            throw new IllegalArgumentException("default.cars cannot exceed maximum.cars.");
        }
        if (defaultIntersections > maxIntersections) {
            throw new IllegalArgumentException(
                    "default.intersections cannot exceed maximum.intersections.");
        }
    }

    /** Loads the named file or returns defaults when it is absent. */
    public static SimulationConfig load(Path path) {
        Properties properties = new Properties();
        if (path != null && Files.isRegularFile(path)) {
            try (InputStream input = Files.newInputStream(path)) {
                properties.load(input);
            } catch (IOException exception) {
                System.err.println(
                        "Unable to read " + path + "; using defaults. " + exception.getMessage());
            }
        }
        return new SimulationConfig(properties);
    }

    /** Returns a default configuration for tests and fallback use. */
    public static SimulationConfig defaults() {
        return new SimulationConfig(new Properties());
    }

    private static int positiveInt(Properties properties, String key, int defaultValue) {
        String rawValue = properties.getProperty(key);
        if (rawValue == null || rawValue.isBlank()) {
            return defaultValue;
        }
        try {
            int value = Integer.parseInt(rawValue.trim());
            if (value <= 0) {
                throw new IllegalArgumentException(key + " must be greater than zero.");
            }
            return value;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(key + " must be a whole number.", exception);
        }
    }

    public int getDefaultIntersections() {
        return defaultIntersections;
    }

    public int getDefaultCars() {
        return defaultCars;
    }

    public int getIntersectionSpacingMeters() {
        return intersectionSpacingMeters;
    }

    public int getGreenSeconds() {
        return greenSeconds;
    }

    public int getYellowSeconds() {
        return yellowSeconds;
    }

    public int getRedSeconds() {
        return redSeconds;
    }

    public int getCarUpdateMilliseconds() {
        return carUpdateMilliseconds;
    }

    public int getMaxCars() {
        return maxCars;
    }

    public int getMaxIntersections() {
        return maxIntersections;
    }

    public int durationSecondsFor(TrafficLightState state) {
        switch (state) {
            case GREEN:
                return greenSeconds;
            case YELLOW:
                return yellowSeconds;
            case RED:
                return redSeconds;
            default:
                throw new IllegalStateException("Unexpected traffic-light state: " + state);
        }
    }
}
