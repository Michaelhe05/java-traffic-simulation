/*
 * File: TrafficCanvas.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Draws the road, intersections, traffic lights, and moving cars.
 */

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.List;
import javax.swing.JPanel;

/** Custom Swing panel that visualizes the simulation. */
@SuppressWarnings("serial")
public final class TrafficCanvas extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final int LEFT_MARGIN = 70;
    private static final int RIGHT_MARGIN = 60;
    private static final int ROAD_Y = 190;

    private final SimulationController controller;

    public TrafficCanvas(SimulationController controller) {
        this.controller = controller;
        setBackground(new Color(242, 246, 250));
        setPreferredSize(new Dimension(1050, 360));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g2 = (Graphics2D) graphics.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            drawTitle(g2);
            drawRoad(g2);
            drawIntersections(g2, controller.getIntersectionsSnapshot());
            drawCars(g2, controller.getCarsSnapshot());
        } finally {
            g2.dispose();
        }
    }

    private void drawTitle(Graphics2D g2) {
        g2.setColor(new Color(34, 48, 74));
        g2.setFont(getFont().deriveFont(Font.BOLD, 17.0f));
        g2.drawString("Straight-Road Traffic Simulation (model Y = 0 meters)", 24, 30);
    }

    private void drawRoad(Graphics2D g2) {
        int roadWidth = Math.max(100, getWidth() - LEFT_MARGIN - RIGHT_MARGIN);
        g2.setColor(new Color(72, 76, 82));
        g2.fillRoundRect(LEFT_MARGIN, ROAD_Y - 38, roadWidth, 76, 18, 18);
        g2.setStroke(new BasicStroke(3.0f));
        g2.setColor(Color.WHITE);
        for (int x = LEFT_MARGIN + 15; x < LEFT_MARGIN + roadWidth - 20; x += 55) {
            g2.drawLine(x, ROAD_Y, Math.min(x + 30, LEFT_MARGIN + roadWidth), ROAD_Y);
        }
        g2.setFont(getFont().deriveFont(Font.PLAIN, 12.0f));
        g2.setColor(new Color(34, 48, 74));
        g2.drawString("X = 0 m", LEFT_MARGIN - 15, ROAD_Y + 65);
        g2.drawString(
                String.format("Road loop end = %.0f m", controller.getRoadEndMeters()),
                Math.max(LEFT_MARGIN, getWidth() - 220),
                ROAD_Y + 65);
    }

    private void drawIntersections(Graphics2D g2, List<Intersection> intersections) {
        double roadEnd = Math.max(1.0, controller.getRoadEndMeters());
        for (Intersection intersection : intersections) {
            int x = scaleX(intersection.getXMeters(), roadEnd);
            g2.setColor(new Color(205, 210, 216));
            g2.fillRect(x - 18, ROAD_Y - 70, 36, 140);
            g2.setColor(new Color(34, 48, 74));
            g2.setStroke(new BasicStroke(2.0f));
            g2.drawLine(x, ROAD_Y - 95, x, ROAD_Y - 48);
            drawSignal(g2, x - 13, ROAD_Y - 140, intersection.getState());
            g2.setFont(getFont().deriveFont(Font.BOLD, 12.0f));
            g2.drawString("I" + intersection.getId(), x - 7, ROAD_Y + 88);
            g2.setFont(getFont().deriveFont(Font.PLAIN, 11.0f));
            g2.drawString(String.format("%.0f m", intersection.getXMeters()), x - 20, ROAD_Y + 104);
        }
    }

    private void drawSignal(Graphics2D g2, int x, int y, TrafficLightState state) {
        g2.setColor(new Color(42, 45, 50));
        g2.fillRoundRect(x, y, 26, 68, 8, 8);
        drawLamp(g2, x + 6, y + 6, Color.RED, state == TrafficLightState.RED);
        drawLamp(g2, x + 6, y + 26, Color.YELLOW, state == TrafficLightState.YELLOW);
        drawLamp(g2, x + 6, y + 46, new Color(0, 165, 75), state == TrafficLightState.GREEN);
    }

    private void drawLamp(Graphics2D g2, int x, int y, Color activeColor, boolean active) {
        g2.setColor(active ? activeColor : new Color(95, 98, 102));
        g2.fillOval(x, y, 14, 14);
    }

    private void drawCars(Graphics2D g2, List<SimulatedCar> cars) {
        double roadEnd = Math.max(1.0, controller.getRoadEndMeters());
        int[] laneOffsets = {-23, 6, -9, 20};
        for (SimulatedCar car : cars) {
            int x = scaleX(car.getXMeters(), roadEnd);
            int y = ROAD_Y + laneOffsets[(car.getId() - 1) % laneOffsets.length];
            Color carColor = Color.getHSBColor((car.getId() * 0.13f) % 1.0f, 0.66f, 0.85f);
            g2.setColor(carColor);
            g2.fillRoundRect(x - 16, y - 9, 32, 18, 7, 7);
            g2.setColor(Color.BLACK);
            g2.drawRoundRect(x - 16, y - 9, 32, 18, 7, 7);
            g2.fillOval(x - 11, y + 6, 7, 7);
            g2.fillOval(x + 5, y + 6, 7, 7);
            g2.setFont(getFont().deriveFont(Font.BOLD, 10.0f));
            g2.drawString("C" + car.getId(), x - 7, y - 13);
        }
    }

    private int scaleX(double modelX, double roadEnd) {
        int usableWidth = Math.max(100, getWidth() - LEFT_MARGIN - RIGHT_MARGIN);
        double ratio = Math.max(0.0, Math.min(1.0, modelX / roadEnd));
        return LEFT_MARGIN + (int) Math.round(ratio * usableWidth);
    }
}
