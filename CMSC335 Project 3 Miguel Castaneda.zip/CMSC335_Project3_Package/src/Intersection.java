/*
 * File: Intersection.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Stores the location and current signal state of one intersection.
 */

/** Thread-safe model of one traffic-light-controlled intersection. */
public final class Intersection {
    private final int id;
    private final double xMeters;
    private volatile TrafficLightState state;
    private volatile String workerThreadName;

    /**
     * Creates an intersection.
     *
     * @param id unique positive identifier
     * @param xMeters position along the road in meters
     * @param initialState initial signal state
     */
    public Intersection(int id, double xMeters, TrafficLightState initialState) {
        if (id <= 0) {
            throw new IllegalArgumentException("Intersection id must be positive.");
        }
        if (xMeters <= 0.0) {
            throw new IllegalArgumentException("Intersection position must be positive.");
        }
        if (initialState == null) {
            throw new IllegalArgumentException("Initial state is required.");
        }
        this.id = id;
        this.xMeters = xMeters;
        this.state = initialState;
        this.workerThreadName = "Not started";
    }

    public int getId() {
        return id;
    }

    public double getXMeters() {
        return xMeters;
    }

    public TrafficLightState getState() {
        return state;
    }

    public void setState(TrafficLightState newState) {
        if (newState == null) {
            throw new IllegalArgumentException("Traffic-light state is required.");
        }
        state = newState;
    }

    public String getWorkerThreadName() {
        return workerThreadName;
    }

    public void setWorkerThreadName(String name) {
        workerThreadName = name == null ? "Unknown" : name;
    }
}
