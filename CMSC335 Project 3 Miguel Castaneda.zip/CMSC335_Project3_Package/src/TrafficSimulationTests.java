/*
 * File: TrafficSimulationTests.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Runs dependency-free automated tests for core simulation behavior.
 */

import java.time.LocalDateTime;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Simple automated test runner that requires no third-party testing framework. */
public final class TrafficSimulationTests {
    private int passed;
    private int failed;

    public static void main(String[] args) {
        TrafficSimulationTests tests = new TrafficSimulationTests();
        tests.runAll();
    }

    private void runAll() {
        run("Kilometers/hour conversion", this::testSpeedConversion);
        run("Distance equals speed times time", this::testDistanceFormula);
        run("Car stops at a red light", this::testRedLightStop);
        run("Car continues through yellow", this::testYellowLightContinue);
        run("Car continues through green", this::testGreenLightContinue);
        run("Default model contains three cars and intersections", this::testDefaultCounts);
        run("Add car and intersection", this::testAddModels);
        run("Start, pause, continue, and stop lifecycle", this::testLifecycle);
        run("Clock produces one-second threaded updates", this::testClockThread);
        run("External CSV test data is readable", this::testCsvDataFile);

        System.out.println();
        System.out.println("Automated test summary: " + passed + " passed, " + failed + " failed.");
        if (failed > 0) {
            throw new AssertionError("One or more automated tests failed.");
        }
    }

    private void run(String name, CheckedTest test) {
        try {
            test.execute();
            passed++;
            System.out.println("PASS - " + name);
        } catch (Exception | AssertionError exception) {
            failed++;
            System.out.println("FAIL - " + name + ": " + exception.getMessage());
        }
    }

    private void testSpeedConversion() {
        assertNear(20.0, SimulatedCar.kilometersPerHourToMetersPerSecond(72.0), 0.0001);
    }

    private void testDistanceFormula() {
        SimulatedCar car = new SimulatedCar(1, 0.0, 72.0);
        car.advance(10.0, new ArrayList<>(), 5000.0);
        assertNear(200.0, car.getXMeters(), 0.0001);
    }

    private void testRedLightStop() {
        SimulatedCar car = new SimulatedCar(1, 980.0, 72.0);
        Intersection red = new Intersection(1, 1000.0, TrafficLightState.RED);
        car.advance(1.0, List.of(red), 2000.0);
        assertNear(985.0, car.getXMeters(), 0.0001);
        assertNear(0.0, car.getActualSpeedKmh(), 0.0001);
    }

    private void testYellowLightContinue() {
        SimulatedCar car = new SimulatedCar(1, 980.0, 72.0);
        Intersection yellow = new Intersection(1, 1000.0, TrafficLightState.YELLOW);
        car.advance(1.0, List.of(yellow), 2000.0);
        assertNear(1000.0, car.getXMeters(), 0.0001);
        assertNear(72.0, car.getActualSpeedKmh(), 0.0001);
    }

    private void testGreenLightContinue() {
        SimulatedCar car = new SimulatedCar(1, 980.0, 72.0);
        Intersection green = new Intersection(1, 1000.0, TrafficLightState.GREEN);
        car.advance(1.0, List.of(green), 2000.0);
        assertNear(1000.0, car.getXMeters(), 0.0001);
        assertNear(72.0, car.getActualSpeedKmh(), 0.0001);
    }

    private void testDefaultCounts() {
        RecordingListener listener = new RecordingListener();
        SimulationController controller =
                new SimulationController(SimulationConfig.defaults(), listener);
        assertEquals(3, controller.getCarsSnapshot().size());
        assertEquals(3, controller.getIntersectionsSnapshot().size());
    }

    private void testAddModels() {
        RecordingListener listener = new RecordingListener();
        SimulationController controller =
                new SimulationController(SimulationConfig.defaults(), listener);
        controller.addCar(80.0);
        controller.addIntersection();
        assertEquals(4, controller.getCarsSnapshot().size());
        assertEquals(4, controller.getIntersectionsSnapshot().size());
        assertNear(4000.0, controller.getIntersectionsSnapshot().get(3).getXMeters(), 0.0001);
    }

    private void testLifecycle() throws InterruptedException {
        RecordingListener listener = new RecordingListener();
        SimulationController controller =
                new SimulationController(SimulationConfig.defaults(), listener);
        controller.start();
        Thread.sleep(150L);
        assertEquals(SimulationStatus.RUNNING, controller.getStatus());
        assertEquals(7, controller.getWorkerThreadCount());
        controller.pause();
        assertEquals(SimulationStatus.PAUSED, controller.getStatus());
        controller.resume();
        assertEquals(SimulationStatus.RUNNING, controller.getStatus());
        controller.stop();
        assertEquals(SimulationStatus.STOPPED, controller.getStatus());
    }

    private void testClockThread() throws InterruptedException {
        RecordingListener listener = new RecordingListener();
        SimulationController controller =
                new SimulationController(SimulationConfig.defaults(), listener);
        controller.start();
        boolean receivedTwoTicks = listener.clockLatch.await(2500L, TimeUnit.MILLISECONDS);
        controller.stop();
        assertTrue(receivedTwoTicks, "Expected at least two clock ticks within 2.5 seconds.");
        assertTrue(
                listener.clockThreadNames.stream().allMatch(name -> name.equals("Simulation-Clock")),
                "Clock updates must originate from the dedicated Simulation-Clock thread.");
    }


    private void testCsvDataFile() throws IOException {
        Path path = Path.of("test-data", "test-data.csv");
        List<String> lines = Files.readAllLines(path);
        assertEquals(7, lines.size());
        assertTrue(
                lines.stream().anyMatch(line -> line.startsWith("Red-light stop,")),
                "Expected red-light test data in test-data.csv.");
    }

    private static void assertNear(double expected, double actual, double tolerance) {
        if (Math.abs(expected - actual) > tolerance) {
            throw new AssertionError("Expected " + expected + " but found " + actual + ".");
        }
    }

    private static void assertEquals(Object expected, Object actual) {
        if (!expected.equals(actual)) {
            throw new AssertionError("Expected " + expected + " but found " + actual + ".");
        }
    }

    private static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    @FunctionalInterface
    private interface CheckedTest {
        void execute() throws Exception;
    }

    private static final class RecordingListener implements SimulationListener {
        private final CountDownLatch clockLatch = new CountDownLatch(2);
        private final List<String> clockThreadNames = new ArrayList<>();

        @Override
        public synchronized void onClockTick(LocalDateTime timestamp, String threadName) {
            clockThreadNames.add(threadName);
            clockLatch.countDown();
        }

        @Override
        public void onIntersectionUpdated(Intersection intersection) {
            // No GUI is needed for model/controller tests.
        }

        @Override
        public void onCarUpdated(SimulatedCar car) {
            // No GUI is needed for model/controller tests.
        }

        @Override
        public void onStatusChanged(SimulationStatus status) {
            // Status is read directly from the controller.
        }

        @Override
        public void onLogMessage(String message) {
            // Log output is not needed for these automated assertions.
        }
    }
}
