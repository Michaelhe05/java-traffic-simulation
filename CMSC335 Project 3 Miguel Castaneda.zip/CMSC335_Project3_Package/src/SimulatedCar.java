/*
 * File: SimulatedCar.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Models a car's X/Y position, speed, and red-light stopping behavior.
 */

import java.util.Comparator;
import java.util.List;

/** Thread-safe model of one car traveling on a straight road. */
public final class SimulatedCar {
    private static final double STOP_DISTANCE_METERS = 15.0;

    private final int id;
    private final double initialXMeters;
    private final double targetSpeedKmh;
    private double xMeters;
    private double actualSpeedKmh;
    private String movementStatus;
    private String workerThreadName;

    /**
     * Creates a car.
     *
     * @param id unique positive identifier
     * @param initialXMeters starting X position in meters
     * @param targetSpeedKmh target speed in kilometers per hour
     */
    public SimulatedCar(int id, double initialXMeters, double targetSpeedKmh) {
        if (id <= 0) {
            throw new IllegalArgumentException("Car id must be positive.");
        }
        if (initialXMeters < 0.0) {
            throw new IllegalArgumentException("Initial X position cannot be negative.");
        }
        if (targetSpeedKmh <= 0.0) {
            throw new IllegalArgumentException("Target speed must be positive.");
        }
        this.id = id;
        this.initialXMeters = initialXMeters;
        this.targetSpeedKmh = targetSpeedKmh;
        reset();
    }

    public int getId() {
        return id;
    }

    public double getTargetSpeedKmh() {
        return targetSpeedKmh;
    }

    public synchronized double getXMeters() {
        return xMeters;
    }

    /** The simulation is one-dimensional, so Y is always zero. */
    public double getYMeters() {
        return 0.0;
    }

    public synchronized double getActualSpeedKmh() {
        return actualSpeedKmh;
    }

    public synchronized String getMovementStatus() {
        return movementStatus;
    }

    public synchronized String getWorkerThreadName() {
        return workerThreadName;
    }

    public synchronized void setWorkerThreadName(String name) {
        workerThreadName = name == null ? "Unknown" : name;
    }

    /** Restores the starting position and stopped state. */
    public synchronized void reset() {
        xMeters = initialXMeters;
        actualSpeedKmh = 0.0;
        movementStatus = "Ready";
        workerThreadName = "Not started";
    }


    /** Marks the car as paused without changing its position. */
    public synchronized void markPaused() {
        actualSpeedKmh = 0.0;
        movementStatus = "Paused";
    }

    /** Marks the car as stopped without changing its position. */
    public synchronized void markStopped() {
        actualSpeedKmh = 0.0;
        movementStatus = "Stopped";
    }

    /** Converts kilometers per hour to meters per second. */
    public static double kilometersPerHourToMetersPerSecond(double speedKmh) {
        return speedKmh / 3.6;
    }

    /**
     * Advances the car by distance = speed * time while obeying red lights.
     * Yellow and green lights do not stop a car, as required by the assignment.
     *
     * @param deltaSeconds elapsed active simulation time in seconds
     * @param intersections current intersections
     * @param roadEndMeters end of the looping road
     */
    public synchronized void advance(
            double deltaSeconds,
            List<Intersection> intersections,
            double roadEndMeters) {
        if (deltaSeconds <= 0.0) {
            return;
        }
        if (intersections == null) {
            throw new IllegalArgumentException("Intersection list is required.");
        }
        if (roadEndMeters <= 0.0) {
            throw new IllegalArgumentException("Road length must be positive.");
        }

        double metersPerSecond = kilometersPerHourToMetersPerSecond(targetSpeedKmh);
        double proposedX = xMeters + metersPerSecond * deltaSeconds;

        Intersection nextIntersection = intersections.stream()
                .filter(intersection -> intersection.getXMeters() > xMeters + 0.001)
                .min(Comparator.comparingDouble(Intersection::getXMeters))
                .orElse(null);

        if (nextIntersection != null && nextIntersection.getState() == TrafficLightState.RED) {
            double stopLineX = nextIntersection.getXMeters() - STOP_DISTANCE_METERS;
            if (proposedX >= stopLineX) {
                xMeters = Math.max(xMeters, stopLineX);
                actualSpeedKmh = 0.0;
                movementStatus = "Stopped at red light I" + nextIntersection.getId();
                return;
            }
        }

        xMeters = proposedX;
        actualSpeedKmh = targetSpeedKmh;
        movementStatus = "Moving";

        if (xMeters > roadEndMeters) {
            xMeters = 0.0;
            movementStatus = "Looped to road start";
        }
    }
}
