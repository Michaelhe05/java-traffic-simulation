/*
 * File: TrafficSimulationFrame.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Builds the Java Swing GUI and connects buttons, menus, and thread callbacks.
 */

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/** Main application window. */
@SuppressWarnings("serial")
public final class TrafficSimulationFrame extends JFrame implements SimulationListener {
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final SimulationController controller;
    private final TrafficCanvas trafficCanvas;
    private final JLabel timeLabel;
    private final JLabel clockThreadLabel;
    private final JLabel statusLabel;
    private final DefaultTableModel carTableModel;
    private final DefaultTableModel intersectionTableModel;
    private final JTextArea logArea;
    private final JSpinner speedSpinner;
    private final JTabbedPane dataTabs;
    private final AtomicBoolean refreshPending;

    private final Action startAction;
    private final Action pauseAction;
    private final Action continueAction;
    private final Action stopAction;
    private final Action addCarAction;
    private final Action addIntersectionAction;

    public TrafficSimulationFrame(SimulationConfig config) {
        super("CMSC 335 Project 3 - Concurrent Traffic Simulation");
        refreshPending = new AtomicBoolean(false);

        timeLabel = new JLabel("Timestamp: Not started");
        timeLabel.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
        clockThreadLabel = new JLabel("Clock thread: Not started");
        statusLabel = new JLabel("Status: STOPPED");
        statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD));
        logArea = new JTextArea(7, 30);
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        speedSpinner = new JSpinner(new SpinnerNumberModel(65.0, 10.0, 160.0, 5.0));
        dataTabs = new JTabbedPane();

        carTableModel = nonEditableModel(new String[] {
            "Car", "X (m)", "Y (m)", "Actual Speed (km/h)", "Target (km/h)", "Status", "Thread"
        });
        intersectionTableModel = nonEditableModel(new String[] {
            "Intersection", "X (m)", "Light", "Thread"
        });

        controller = new SimulationController(config, this);
        trafficCanvas = new TrafficCanvas(controller);

        startAction = new AbstractAction("Start") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                controller.start();
            }
        };
        pauseAction = new AbstractAction("Pause") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                controller.pause();
            }
        };
        continueAction = new AbstractAction("Continue") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                controller.resume();
            }
        };
        stopAction = new AbstractAction("Stop") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                controller.stop();
            }
        };
        addCarAction = new AbstractAction("Add Car") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                try {
                    controller.addCar(((Number) speedSpinner.getValue()).doubleValue());
                    queueRefresh();
                } catch (IllegalStateException exception) {
                    showMessage(exception.getMessage());
                }
            }
        };
        addIntersectionAction = new AbstractAction("Add Intersection") {
            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(java.awt.event.ActionEvent event) {
                try {
                    controller.addIntersection();
                    queueRefresh();
                } catch (IllegalStateException exception) {
                    showMessage(exception.getMessage());
                }
            }
        };

        buildWindow();
        refreshAllViews();
        updateActionStates(SimulationStatus.STOPPED);
    }

    private void buildWindow() {
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent event) {
                controller.stop();
                dispose();
            }
        });
        setJMenuBar(createMenuBar());
        setLayout(new BorderLayout(8, 8));
        add(createHeaderPanel(), BorderLayout.NORTH);
        add(createCenterPanel(), BorderLayout.CENTER);
        add(createControlPanel(), BorderLayout.SOUTH);
        setMinimumSize(new Dimension(1050, 720));
        setSize(1250, 820);
        setLocationRelativeTo(null);
    }

    private JMenuBar createMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu simulationMenu = new JMenu("Simulation");
        simulationMenu.add(new JMenuItem(startAction));
        simulationMenu.add(new JMenuItem(pauseAction));
        simulationMenu.add(new JMenuItem(continueAction));
        simulationMenu.add(new JMenuItem(stopAction));
        simulationMenu.addSeparator();
        simulationMenu.add(new JMenuItem(addCarAction));
        simulationMenu.add(new JMenuItem(addIntersectionAction));

        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(event -> showMessage(
                "CMSC 335 Project 3\nJava Swing traffic simulation with independent worker threads."));
        helpMenu.add(aboutItem);

        bar.add(simulationMenu);
        bar.add(helpMenu);
        return bar;
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 12, 4));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Real-Time Simulation Status"),
                BorderFactory.createEmptyBorder(4, 8, 6, 8)));
        panel.add(timeLabel);
        panel.add(statusLabel);
        panel.add(clockThreadLabel);
        panel.add(new JLabel("Units: distance = meters; speed = kilometers/hour; Y = 0 meters"));
        return panel;
    }

    private JSplitPane createCenterPanel() {
        JPanel visualizationPanel = new JPanel(new BorderLayout());
        visualizationPanel.setBorder(BorderFactory.createTitledBorder("Traffic Visualization"));
        visualizationPanel.add(trafficCanvas, BorderLayout.CENTER);

        JTable carTable = new JTable(carTableModel);
        carTable.setAutoCreateRowSorter(true);
        JTable intersectionTable = new JTable(intersectionTableModel);
        intersectionTable.setAutoCreateRowSorter(true);
        dataTabs.addTab("Cars", new JScrollPane(carTable));
        dataTabs.addTab("Intersections", new JScrollPane(intersectionTable));
        dataTabs.addTab("Thread Log", new JScrollPane(logArea));
        dataTabs.setPreferredSize(new Dimension(1000, 250));

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                visualizationPanel,
                dataTabs);
        splitPane.setResizeWeight(0.60);
        splitPane.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        return splitPane;
    }

    private JPanel createControlPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Simulation Controls"),
                BorderFactory.createEmptyBorder(4, 8, 8, 8)));

        JPanel lifecyclePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lifecyclePanel.add(new JButton(startAction));
        lifecyclePanel.add(new JButton(pauseAction));
        lifecyclePanel.add(new JButton(continueAction));
        lifecyclePanel.add(new JButton(stopAction));

        JPanel addPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(2, 5, 2, 5);
        constraints.gridx = 0;
        constraints.gridy = 0;
        addPanel.add(new JLabel("New car speed (km/h):"), constraints);
        constraints.gridx = 1;
        addPanel.add(speedSpinner, constraints);
        constraints.gridx = 2;
        addPanel.add(new JButton(addCarAction), constraints);
        constraints.gridx = 3;
        addPanel.add(new JButton(addIntersectionAction), constraints);

        outer.add(lifecyclePanel, BorderLayout.WEST);
        outer.add(addPanel, BorderLayout.EAST);
        return outer;
    }

    private static DefaultTableModel nonEditableModel(String[] columns) {
        return new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Traffic Simulation", JOptionPane.INFORMATION_MESSAGE);
    }

    private void queueRefresh() {
        if (refreshPending.compareAndSet(false, true)) {
            SwingUtilities.invokeLater(() -> {
                refreshPending.set(false);
                refreshAllViews();
            });
        }
    }

    private void refreshAllViews() {
        refreshCarTable(controller.getCarsSnapshot());
        refreshIntersectionTable(controller.getIntersectionsSnapshot());
        trafficCanvas.repaint();
    }

    private void refreshCarTable(List<SimulatedCar> cars) {
        carTableModel.setRowCount(0);
        for (SimulatedCar car : cars) {
            carTableModel.addRow(new Object[] {
                "Car " + car.getId(),
                String.format("%.1f", car.getXMeters()),
                String.format("%.1f", car.getYMeters()),
                String.format("%.1f", car.getActualSpeedKmh()),
                String.format("%.1f", car.getTargetSpeedKmh()),
                car.getMovementStatus(),
                car.getWorkerThreadName()
            });
        }
    }

    private void refreshIntersectionTable(List<Intersection> intersections) {
        intersectionTableModel.setRowCount(0);
        for (Intersection intersection : intersections) {
            intersectionTableModel.addRow(new Object[] {
                "Intersection " + intersection.getId(),
                String.format("%.0f", intersection.getXMeters()),
                intersection.getState(),
                intersection.getWorkerThreadName()
            });
        }
    }

    private void updateActionStates(SimulationStatus newStatus) {
        startAction.setEnabled(newStatus == SimulationStatus.STOPPED);
        pauseAction.setEnabled(newStatus == SimulationStatus.RUNNING);
        continueAction.setEnabled(newStatus == SimulationStatus.PAUSED);
        stopAction.setEnabled(newStatus != SimulationStatus.STOPPED);
        addCarAction.setEnabled(true);
        addIntersectionAction.setEnabled(true);
    }

    @Override
    public void onClockTick(LocalDateTime timestamp, String threadName) {
        SwingUtilities.invokeLater(() -> {
            timeLabel.setText("Timestamp: " + TIME_FORMATTER.format(timestamp));
            clockThreadLabel.setText("Clock thread: " + threadName);
        });
    }

    @Override
    public void onIntersectionUpdated(Intersection intersection) {
        queueRefresh();
    }

    @Override
    public void onCarUpdated(SimulatedCar car) {
        queueRefresh();
    }

    @Override
    public void onStatusChanged(SimulationStatus newStatus) {
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText("Status: " + newStatus);
            updateActionStates(newStatus);
            refreshAllViews();
        });
    }

    @Override
    public void onLogMessage(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append("[" + TIME_FORMATTER.format(LocalDateTime.now()) + "] " + message + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    /* Package-private methods used only to capture reproducible documentation screenshots. */
    void documentationStart() {
        startAction.actionPerformed(null);
    }

    void documentationPause() {
        pauseAction.actionPerformed(null);
    }

    void documentationContinue() {
        continueAction.actionPerformed(null);
    }

    void documentationStop() {
        stopAction.actionPerformed(null);
    }

    void documentationAddCar() {
        addCarAction.actionPerformed(null);
    }

    void documentationAddIntersection() {
        addIntersectionAction.actionPerformed(null);
    }

    void documentationShowCarsTab() {
        dataTabs.setSelectedIndex(0);
    }

    void documentationShowIntersectionsTab() {
        dataTabs.setSelectedIndex(1);
    }
}
