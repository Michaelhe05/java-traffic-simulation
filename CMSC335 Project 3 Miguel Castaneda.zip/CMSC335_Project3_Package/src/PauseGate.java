/*
 * File: PauseGate.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Coordinates pause and continue behavior across all worker threads.
 */

import java.util.concurrent.atomic.AtomicBoolean;

/** Shared monitor used to pause and resume simulation workers. */
public final class PauseGate {
    private final Object monitor = new Object();
    private volatile boolean paused;

    public void pause() {
        paused = true;
    }

    public void resume() {
        synchronized (monitor) {
            paused = false;
            monitor.notifyAll();
        }
    }

    public boolean isPaused() {
        return paused;
    }

    /** Waits while paused and returns immediately after stop or resume. */
    public void awaitActive(AtomicBoolean runFlag) throws InterruptedException {
        synchronized (monitor) {
            while (paused && runFlag.get()) {
                monitor.wait();
            }
        }
    }
}
