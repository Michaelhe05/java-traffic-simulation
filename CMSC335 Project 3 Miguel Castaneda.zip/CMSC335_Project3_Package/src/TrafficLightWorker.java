/*
 * File: TrafficLightWorker.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Runs one intersection's independent real-time light cycle.
 */

import java.util.concurrent.atomic.AtomicBoolean;

/** Runnable that controls exactly one intersection on its own thread. */
public final class TrafficLightWorker implements Runnable {
    private final Intersection intersection;
    private final SimulationConfig config;
    private final AtomicBoolean runFlag;
    private final PauseGate pauseGate;
    private final SimulationListener listener;

    public TrafficLightWorker(
            Intersection intersection,
            SimulationConfig config,
            AtomicBoolean runFlag,
            PauseGate pauseGate,
            SimulationListener listener) {
        this.intersection = intersection;
        this.config = config;
        this.runFlag = runFlag;
        this.pauseGate = pauseGate;
        this.listener = listener;
    }

    @Override
    public void run() {
        intersection.setWorkerThreadName(Thread.currentThread().getName());
        listener.onIntersectionUpdated(intersection);

        while (runFlag.get()) {
            try {
                int requiredMilliseconds =
                        config.durationSecondsFor(intersection.getState()) * 1000;
                int activeMilliseconds = 0;
                while (activeMilliseconds < requiredMilliseconds && runFlag.get()) {
                    pauseGate.awaitActive(runFlag);
                    if (!runFlag.get()) {
                        return;
                    }
                    Thread.sleep(100L);
                    activeMilliseconds += 100;
                }
                if (runFlag.get()) {
                    intersection.setState(intersection.getState().next());
                    listener.onIntersectionUpdated(intersection);
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
