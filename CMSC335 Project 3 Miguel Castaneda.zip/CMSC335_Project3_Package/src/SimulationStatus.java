/*
 * File: SimulationStatus.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Defines the lifecycle states of the traffic simulation.
 */

/** Represents the current lifecycle state of the simulation. */
public enum SimulationStatus {
    STOPPED,
    RUNNING,
    PAUSED
}
