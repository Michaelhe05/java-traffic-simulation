/*
 * File: CarWorker.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Updates one car's position and speed on an independent thread.
 */

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.DoubleSupplier;

/** Runnable that controls exactly one car on its own thread. */
public final class CarWorker implements Runnable {
    private final SimulatedCar car;
    private final List<Intersection> intersections;
    private final SimulationConfig config;
    private final AtomicBoolean runFlag;
    private final PauseGate pauseGate;
    private final DoubleSupplier roadEndSupplier;
    private final SimulationListener listener;

    public CarWorker(
            SimulatedCar car,
            List<Intersection> intersections,
            SimulationConfig config,
            AtomicBoolean runFlag,
            PauseGate pauseGate,
            DoubleSupplier roadEndSupplier,
            SimulationListener listener) {
        this.car = car;
        this.intersections = intersections;
        this.config = config;
        this.runFlag = runFlag;
        this.pauseGate = pauseGate;
        this.roadEndSupplier = roadEndSupplier;
        this.listener = listener;
    }

    @Override
    public void run() {
        car.setWorkerThreadName(Thread.currentThread().getName());
        listener.onCarUpdated(car);
        double deltaSeconds = config.getCarUpdateMilliseconds() / 1000.0;

        while (runFlag.get()) {
            try {
                pauseGate.awaitActive(runFlag);
                if (!runFlag.get()) {
                    break;
                }
                car.advance(deltaSeconds, intersections, roadEndSupplier.getAsDouble());
                listener.onCarUpdated(car);
                Thread.sleep(config.getCarUpdateMilliseconds());
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}
