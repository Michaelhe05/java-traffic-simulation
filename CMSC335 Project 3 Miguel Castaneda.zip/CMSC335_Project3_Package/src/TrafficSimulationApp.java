/*
 * File: TrafficSimulationApp.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Provides the main entry point for the CMSC 335 traffic simulation.
 */

import java.nio.file.Path;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/** Launches the application on Swing's Event Dispatch Thread. */
public final class TrafficSimulationApp {
    private TrafficSimulationApp() {
        // Utility class; no instances are needed.
    }

    public static void main(String[] args) {
        setSystemLookAndFeel();
        SimulationConfig config = SimulationConfig.load(Path.of("config", "simulation.properties"));
        SwingUtilities.invokeLater(() -> {
            TrafficSimulationFrame frame = new TrafficSimulationFrame(config);
            frame.setVisible(true);
        });
    }

    private static void setSystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException
                | InstantiationException
                | IllegalAccessException
                | UnsupportedLookAndFeelException exception) {
            System.err.println("System look and feel was unavailable; using Swing default.");
        }
    }
}
