/*
 * File: ClockWorker.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Updates the GUI timestamp once per active simulation second.
 */

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicBoolean;

/** Runnable responsible only for one-second timestamp updates. */
public final class ClockWorker implements Runnable {
    private final AtomicBoolean runFlag;
    private final PauseGate pauseGate;
    private final SimulationListener listener;

    public ClockWorker(
            AtomicBoolean runFlag,
            PauseGate pauseGate,
            SimulationListener listener) {
        this.runFlag = runFlag;
        this.pauseGate = pauseGate;
        this.listener = listener;
    }

    @Override
    public void run() {
        while (runFlag.get()) {
            try {
                pauseGate.awaitActive(runFlag);
                if (!runFlag.get()) {
                    break;
                }
                listener.onClockTick(LocalDateTime.now(), Thread.currentThread().getName());
                sleepOneActiveSecond();
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void sleepOneActiveSecond() throws InterruptedException {
        int elapsedMilliseconds = 0;
        while (elapsedMilliseconds < 1000 && runFlag.get()) {
            pauseGate.awaitActive(runFlag);
            if (!runFlag.get()) {
                return;
            }
            Thread.sleep(100L);
            elapsedMilliseconds += 100;
        }
    }
}
