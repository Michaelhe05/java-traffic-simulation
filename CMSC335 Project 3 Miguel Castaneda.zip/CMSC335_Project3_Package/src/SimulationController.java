/*
 * File: SimulationController.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Owns simulation models, lifecycle controls, and worker-thread creation.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/** Coordinates the simulation while keeping GUI and worker responsibilities separate. */
public final class SimulationController {
    private final SimulationConfig config;
    private final SimulationListener listener;
    private final CopyOnWriteArrayList<Intersection> intersections;
    private final CopyOnWriteArrayList<SimulatedCar> cars;
    private final CopyOnWriteArrayList<Thread> workerThreads;
    private final PauseGate pauseGate;

    private volatile SimulationStatus status;
    private volatile AtomicBoolean activeRunFlag;

    public SimulationController(SimulationConfig config, SimulationListener listener) {
        if (config == null || listener == null) {
            throw new IllegalArgumentException("Configuration and listener are required.");
        }
        this.config = config;
        this.listener = listener;
        intersections = new CopyOnWriteArrayList<>();
        cars = new CopyOnWriteArrayList<>();
        workerThreads = new CopyOnWriteArrayList<>();
        pauseGate = new PauseGate();
        status = SimulationStatus.STOPPED;
        activeRunFlag = new AtomicBoolean(false);
        createDefaultModels();
    }

    private void createDefaultModels() {
        for (int index = 0; index < config.getDefaultIntersections(); index++) {
            TrafficLightState initialState;
            switch (index % 3) {
                case 0:
                    initialState = TrafficLightState.GREEN;
                    break;
                case 1:
                    initialState = TrafficLightState.YELLOW;
                    break;
                default:
                    initialState = TrafficLightState.RED;
                    break;
            }
            intersections.add(new Intersection(
                    index + 1,
                    (index + 1) * config.getIntersectionSpacingMeters(),
                    initialState));
        }

        double[] startingPositions = {850.0, 1850.0, 2930.0};
        double[] defaultSpeeds = {60.0, 72.0, 90.0};
        for (int index = 0; index < config.getDefaultCars(); index++) {
            double start = index < startingPositions.length
                    ? startingPositions[index]
                    : index * 150.0;
            double speed = index < defaultSpeeds.length
                    ? defaultSpeeds[index]
                    : 65.0 + index * 5.0;
            cars.add(new SimulatedCar(index + 1, start, speed));
        }
    }

    public synchronized void start() {
        if (status != SimulationStatus.STOPPED) {
            return;
        }
        for (SimulatedCar car : cars) {
            car.reset();
        }
        resetIntersectionStates();
        pauseGate.resume();
        workerThreads.clear();
        activeRunFlag = new AtomicBoolean(true);
        status = SimulationStatus.RUNNING;
        listener.onStatusChanged(status);
        listener.onLogMessage("Simulation started with " + cars.size() + " cars and "
                + intersections.size() + " intersections.");

        startThread(new ClockWorker(activeRunFlag, pauseGate, listener), "Simulation-Clock");
        for (Intersection intersection : intersections) {
            startTrafficLightWorker(intersection, activeRunFlag);
        }
        for (SimulatedCar car : cars) {
            startCarWorker(car, activeRunFlag);
        }
    }

    public synchronized void pause() {
        if (status == SimulationStatus.RUNNING) {
            pauseGate.pause();
            for (SimulatedCar car : cars) {
                car.markPaused();
                listener.onCarUpdated(car);
            }
            status = SimulationStatus.PAUSED;
            listener.onStatusChanged(status);
            listener.onLogMessage("Simulation paused; all component threads are waiting.");
        }
    }

    public synchronized void resume() {
        if (status == SimulationStatus.PAUSED) {
            pauseGate.resume();
            status = SimulationStatus.RUNNING;
            listener.onStatusChanged(status);
            listener.onLogMessage("Simulation continued.");
        }
    }

    public synchronized void stop() {
        if (status == SimulationStatus.STOPPED) {
            return;
        }
        activeRunFlag.set(false);
        pauseGate.resume();
        for (Thread thread : workerThreads) {
            thread.interrupt();
        }
        workerThreads.clear();
        for (SimulatedCar car : cars) {
            car.markStopped();
            listener.onCarUpdated(car);
        }
        status = SimulationStatus.STOPPED;
        listener.onStatusChanged(status);
        listener.onLogMessage("Simulation stopped; all worker threads were interrupted.");
    }

    public synchronized SimulatedCar addCar(double speedKmh) {
        if (cars.size() >= config.getMaxCars()) {
            throw new IllegalStateException(
                    "The configured maximum of " + config.getMaxCars() + " cars was reached.");
        }
        int id = cars.size() + 1;
        double startX = ((id - 1) * 125.0) % config.getIntersectionSpacingMeters();
        SimulatedCar car = new SimulatedCar(id, startX, speedKmh);
        cars.add(car);
        listener.onCarUpdated(car);
        listener.onLogMessage("Added Car " + id + " at " + speedKmh + " km/h.");
        if (status != SimulationStatus.STOPPED) {
            startCarWorker(car, activeRunFlag);
        }
        return car;
    }

    public synchronized Intersection addIntersection() {
        if (intersections.size() >= config.getMaxIntersections()) {
            throw new IllegalStateException("The configured maximum of "
                    + config.getMaxIntersections() + " intersections was reached.");
        }
        int id = intersections.size() + 1;
        double x = id * config.getIntersectionSpacingMeters();
        TrafficLightState initialState = TrafficLightState.values()[(id - 1) % 3];
        Intersection intersection = new Intersection(id, x, initialState);
        intersections.add(intersection);
        listener.onIntersectionUpdated(intersection);
        listener.onLogMessage("Added Intersection " + id + " at X=" + x + " meters.");
        if (status != SimulationStatus.STOPPED) {
            startTrafficLightWorker(intersection, activeRunFlag);
        }
        return intersection;
    }

    private void resetIntersectionStates() {
        for (int index = 0; index < intersections.size(); index++) {
            TrafficLightState state;
            switch (index % 3) {
                case 0:
                    state = TrafficLightState.GREEN;
                    break;
                case 1:
                    state = TrafficLightState.YELLOW;
                    break;
                default:
                    state = TrafficLightState.RED;
                    break;
            }
            Intersection intersection = intersections.get(index);
            intersection.setState(state);
            intersection.setWorkerThreadName("Not started");
        }
    }

    private void startTrafficLightWorker(Intersection intersection, AtomicBoolean runFlag) {
        startThread(
                new TrafficLightWorker(intersection, config, runFlag, pauseGate, listener),
                "Traffic-Light-" + intersection.getId());
    }

    private void startCarWorker(SimulatedCar car, AtomicBoolean runFlag) {
        startThread(
                new CarWorker(
                        car,
                        intersections,
                        config,
                        runFlag,
                        pauseGate,
                        this::getRoadEndMeters,
                        listener),
                "Car-Worker-" + car.getId());
    }

    private void startThread(Runnable task, String name) {
        Thread thread = new Thread(task, name);
        thread.setDaemon(true);
        workerThreads.add(thread);
        thread.start();
    }

    public List<Intersection> getIntersectionsSnapshot() {
        return Collections.unmodifiableList(new ArrayList<>(intersections));
    }

    public List<SimulatedCar> getCarsSnapshot() {
        return Collections.unmodifiableList(new ArrayList<>(cars));
    }

    public double getRoadEndMeters() {
        return (intersections.size() + 1.0) * config.getIntersectionSpacingMeters();
    }

    public SimulationStatus getStatus() {
        return status;
    }

    public int getWorkerThreadCount() {
        return workerThreads.size();
    }
}
