/*
 * File: TrafficLightState.java
 * Date: July 3, 2026
 * Author: Miguel Castaneda
 * Purpose: Defines the supported traffic-light states and their sequence.
 */

/** Represents one state in a traffic-light cycle. */
public enum TrafficLightState {
    GREEN,
    YELLOW,
    RED;

    /**
     * Returns the next state in the Green -> Yellow -> Red -> Green cycle.
     *
     * @return the next traffic-light state
     */
    public TrafficLightState next() {
        switch (this) {
            case GREEN:
                return YELLOW;
            case YELLOW:
                return RED;
            case RED:
                return GREEN;
            default:
                throw new IllegalStateException("Unexpected traffic-light state: " + this);
        }
    }
}
