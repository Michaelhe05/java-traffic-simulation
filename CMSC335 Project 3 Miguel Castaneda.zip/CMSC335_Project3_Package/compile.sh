#!/usr/bin/env bash
set -euo pipefail
mkdir -p build
javac -Xlint:all -d build src/*.java
echo "Compilation completed with -Xlint:all."
