@echo off
if not exist build mkdir build
javac -Xlint:all -d build src\*.java
if errorlevel 1 exit /b 1
echo Compilation completed with -Xlint:all.
